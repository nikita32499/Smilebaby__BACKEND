export enum EnumViewNames {
  HOME = 'HOME',
}

export function isView(data: unknown): data is IView {
  return (
    typeof data === 'object' &&
    data != null &&
    'id' in data &&
    'name' in data &&
    'payload' in data
  );
}

export interface IView {
  id: number;
  name: EnumViewNames;
  payload: object;
  description: string;
}

export interface ICreateView extends Omit<IView, 'id'> {}

export type ViewAttrValue<Value> = {
  description: string;
  value: Value;
};

/* кастомные интерфейсы страниц */

export type IViewUnion = IView__HOME;

export interface IView__HOME extends IView {
  payload: {
    links: ViewAttrValue<
      {
        id: number;
        text: string;
        url: string;
        number: number;
      }[]
    >;
    logo_url: ViewAttrValue<string>;
  };
}

export const SchemaView__HOME = {
  $schema: 'http://json-schema.org/draft-07/schema#',
  type: 'object',
  properties: {
    payload: {
      type: 'object',
      properties: {
        links: {
          type: 'object',
          properties: {
            description: { type: 'string' },
            value: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  text: {
                    type: 'string',
                  },
                  url: {
                    type: 'string',
                  },
                  number: {
                    type: 'number',
                  },
                  id: { type: 'number' },
                },
                required: ['text', 'url', 'id', 'number'],
              },
            },
          },
          required: ['description', 'value'],
        },
        logo_url: {
          type: 'object',
          properties: {
            description: { type: 'string' },
            value: { type: 'string' },
          },
          required: ['description', 'value'],
        },
      },
      required: ['links', 'logo_url'],
    },
  },
  required: ['payload'],
};
